package lab4smt;

public interface iGreeter {
	
	String sayHello();

}
