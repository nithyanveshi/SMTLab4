package lab4smt;

public class GreeterEnglish implements iGreeter {

	public GreeterEnglish() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String sayHello() {
		// TODO Auto-generated method stub
		return "Hello World";
	}

}
