package lab4smt;

public class GreeterIndian implements iGreeter {

	public GreeterIndian() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String sayHello() {
		// TODO Auto-generated method stub
		return "Namaste";
	}

}
